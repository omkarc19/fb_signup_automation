package fb_automation;

import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class login {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\omkar\\chromedriver_win32\\chromedriver.exe");
		// 1. Open a Chrome browser
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		// 2. Navigate to �https://www.facebook.com/�
		driver.get("https://www.facebook.com/");

		//3. Access the page to �https://en-gb.facebook.com/�, by getting the current URL
		driver.get("https://en-gb.facebook.com/");
		
		// 4. Verify that there is a �Sign Up� section on the page.
		if(driver.findElement(By.xpath("//a[text()='Create New Account']"))!= null){
			System.out.println("Element is Present");
			}else{
			System.out.println("Element is Absent");
			}
		
		// 5. Write a Test Cases on field validation and also capture the field alert messages and verify
		driver.findElement(By.xpath("//a[text()='Create New Account']")).click();
		Thread.sleep(2000);
		// 6. Fill in the text boxes: First Name, Surname, Mobile Number or email address,�Re-enter mobile number�, new password
		String firstname = "//input[@name='firstname']";
		String lastname = "//input[@name='lastname']";
		String email = "//input[@name='reg_email__']";
		String cnfemail = "//input[@name='reg_email_confirmation__']";
		String password = "//input[@name='reg_passwd__']";
		String dobDate = "//select[@name='birthday_day']";
		String dobMonth = "//select[@name='birthday_month']";
		String dobYear = "//select[@name='birthday_year']";
		String gender = "//input[@name='sex']";
		String submit = "//button[@name='websubmit']";
		
		driver.findElement(By.xpath(firstname)).sendKeys("Omkar");
		driver.findElement(By.xpath(lastname)).sendKeys("Chougale");
		driver.findElement(By.xpath(email)).sendKeys("omkar@loop.one");
		WebDriverWait explicitWait = new WebDriverWait(driver,60);
		
		explicitWait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(cnfemail))));
		driver.findElement(By.xpath(cnfemail)).sendKeys("omkar@loop.one");
		driver.findElement(By.xpath(password)).sendKeys("4Loop.one");
		
		Select selectDate = new Select(driver.findElement(By.xpath(dobDate)));
		selectDate.selectByVisibleText("20");
		
		Select selectMonth = new Select(driver.findElement(By.xpath(dobMonth)));
		selectMonth.selectByVisibleText("Jun");
		
		Select selectYear = new Select(driver.findElement(By.xpath(dobYear)));
		selectYear.selectByVisibleText("1996");
		
		driver.findElements(By.xpath(gender)).get(1).click();
		driver.findElement(By.xpath(submit)).click();
		
		Thread.sleep(2000);
		//driver.close();
	}
}
