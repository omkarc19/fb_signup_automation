package Facebook;

import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

@Test
public class FacebookAutomation {
	
	@Test
	public void m1() throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver","C:\\omkar\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		//Explicit wait (assigning wait time dynamically)
		WebDriverWait expliciWait = new WebDriverWait(driver, 60);

		driver.manage().window().maximize();

		//open chrome and hit Facebook
		driver.get("https://www.facebook.com/");
		
		Actions act = new Actions(driver);
		
		//Click on "Create New Account" link for sign up
		driver.findElement(By.xpath("//div[@class='_6ltg']//a[@role='button']")).click();
		Assert.assertTrue(true);
		Thread.sleep(2000);
		
		//Fill in the text boxes with First Name, Surname, Mobile Number or email address,
		//�Re-enter mobile number�, new password
		driver.findElement(By.xpath("//input[@name='firstname']")).sendKeys("Omkar");
		driver.findElement(By.xpath("//input[@name='lastname']")).sendKeys("Chougale");
		driver.findElement(By.xpath("//input[@name='reg_email__']")).sendKeys("omkar.chougale@zoop.one");
		driver.findElement(By.xpath("//input[@name='reg_passwd__']")).sendKeys("Omkar@123");
		Thread.sleep(2000);
		driver.close();



	}
}
