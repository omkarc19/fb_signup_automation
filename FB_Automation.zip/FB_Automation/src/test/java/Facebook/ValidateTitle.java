package Facebook;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import FBOrg.Base;
import PageObjects.HomePage;
import PageObjects.SignUpPage;

//import FBOrg.Base;

public class ValidateTitle extends Base {

	@BeforeTest
	public void initialize() throws IOException {

		driver = initializeDriver();

		driver.get(prop.getProperty("url"));
	}

	@Test(priority = 1)
	public void validateAppTitle() throws IOException {

		// creating homepage object
		HomePage homepage = new HomePage(driver);

		// one is inheritance
		// creating object to that class and invoke methods of it
		// compare the text from the browser with actual text.- Error..
		Assert.assertTrue(homepage.isSignUpButtonPresent(), "Sign button is not present");
		System.out.println("Test completed");

	}

	@Test(priority = -1)
	public void validateFieldMessages() throws IOException {

		HomePage homepage = new HomePage(driver);
		SignUpPage signUpPage = new SignUpPage(driver);

		homepage.clickOnCreateAcccount();
		signUpPage.clickOnSignUpButton();
		signUpPage.fillSignUpData();

		Assert.assertTrue(signUpPage.fieldValidation(), "Input is not present");
		System.out.println("Test completed");

	}

	@Test(priority = -2)
	public void verifyErrorValidation() throws IOException {

		HomePage homepage = new HomePage(driver);
		SignUpPage signUpPage = new SignUpPage(driver);

		homepage.clickOnCreateAcccount();
		signUpPage.clickOnSignUpButton();

		Assert.assertTrue(signUpPage.getNumberOfValidationErrors() > 6);
	}

	@AfterTest
	public void teardown() {
		driver.close();
	}
}
