package PageObjects;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class HomePage {

	public WebDriver driver;

	private By createNewAccountButton = By.xpath("//a[text()='Create New Account']");

	public HomePage(WebDriver driver) {
		this.driver = driver;
	}

	public boolean isSignUpButtonPresent() {
		if (driver.findElement(createNewAccountButton) != null) {
			return true;
		} else {
			return false;
		}
	}

	public void clickOnCreateAcccount() {
		driver.findElement(createNewAccountButton).click();

	}
}