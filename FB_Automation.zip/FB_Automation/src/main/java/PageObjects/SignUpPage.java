package PageObjects;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class SignUpPage {

	public WebDriver driver;

	private By signUpButton = By.xpath("//button[@name='websubmit']");
	private By firstNameInputField = By.xpath("//input[@name='firstname']");
	private By lastNameInputField = By.xpath("//input[@name='lastname']");
	private By emailInputField = By.xpath("//input[@name='reg_email__']");
	private By reenterEmailInputField = By.xpath("//input[@name='reg_email_confirmation__']");
	private By passInputField = By.xpath("//input[@name='reg_passwd__']");
	private By birthdayInputField = By.xpath("//select[@name='birthday_day']");
	private By birthMonthInputField = By.xpath("//select[@name='birthday_month']");
	private By birthYearInputField = By.xpath("//select[@name='birthday_year']");
	private By sexInputField = By.xpath("//input[@name='sex']//preceding-sibling::label");
	private By errorValidation = By.xpath("//*[contains(@class,'_5dbc')]");

	public SignUpPage(WebDriver driver) {
		this.driver = driver;
	}

	public void clickOnSignUpButton() {
		driver.findElement(signUpButton).click();
	}

	public boolean fieldValidation() {
		JavascriptExecutor js = (JavascriptExecutor) driver;

		WebElement firstname = driver.findElement(firstNameInputField);
		Boolean is_valid = (Boolean) js.executeScript("return arguments[0].checkValidity();", firstname);
		String message = (String) js.executeScript("return arguments[0].validationMessage;", firstname);
		System.out.println(message);
		System.out.println(firstname.getAttribute("validationMessage"));
		return false;
	}

	public void fillSignUpData() {
		driver.findElement(firstNameInputField).sendKeys("Omkar");
		driver.findElement(lastNameInputField).sendKeys("Chougale");
		driver.findElement(emailInputField).sendKeys("omkar.chougale@zoop.one");
		driver.findElement(reenterEmailInputField).sendKeys("omkar.chougale@zoop.one");
		driver.findElement(passInputField).sendKeys("Omkar@123");
		selectValueFromDropDown(driver.findElement(birthdayInputField), "20");
		selectValueFromDropDown(driver.findElement(birthMonthInputField), "Jun");
		selectValueFromDropDown(driver.findElement(birthYearInputField), "1996");
		selectRadioButtonByText(driver.findElements(sexInputField), "Male");
	}

	// getting value from dropdown
	public void selectValueFromDropDown(WebElement element, String value) {
		Select select = new Select(element);
		select.selectByVisibleText(value);

	}

	public void selectRadioButtonByText(List<WebElement> element, String value) {

		for (WebElement el : element) {
			if (el.getText().equals(value)) {
				el.click();
				break;
			}
		}
	}

	public int getNumberOfValidationErrors() {
		return driver.findElements(errorValidation).size();
	}
}
